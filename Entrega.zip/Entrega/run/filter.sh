#!/bin/bash

./probSemSharedMemSmokers | awk -f filter_log.awk

