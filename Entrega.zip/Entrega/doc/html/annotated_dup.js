var annotated_dup =
[
    [ "FULL_STAT", "struct_f_u_l_l___s_t_a_t.html", "struct_f_u_l_l___s_t_a_t" ],
    [ "SHARED_DATA", "struct_s_h_a_r_e_d___d_a_t_a.html", "struct_s_h_a_r_e_d___d_a_t_a" ],
    [ "STAT", "struct_s_t_a_t.html", "struct_s_t_a_t" ]
];