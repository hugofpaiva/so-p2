var shared_data_sync_8h =
[
    [ "SHARED_DATA", "struct_s_h_a_r_e_d___d_a_t_a.html", "struct_s_h_a_r_e_d___d_a_t_a" ],
    [ "INGREDIENT", "shared_data_sync_8h.html#ac90271583be681e842b7b08f3e758dde", null ],
    [ "MUTEX", "shared_data_sync_8h.html#a2cf3c22d8cacfe663a4eec13d0fb26ef", null ],
    [ "SEM_NU", "shared_data_sync_8h.html#a36481187ec581ae5e90bbbd308d740f1", null ],
    [ "WAIT2INGS", "shared_data_sync_8h.html#a34344314f5d25f93bf989b6b0f623dcd", null ],
    [ "WAITCIGARETTE", "shared_data_sync_8h.html#a023ff414d69655eb1e37e1e8c9f84de6", null ]
];