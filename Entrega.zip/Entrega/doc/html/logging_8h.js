var logging_8h =
[
    [ "createLog", "logging_8h.html#a14b9da580ff38a7129ac1f892136164c", null ],
    [ "saveState", "logging_8h.html#a01ad6d5d28960f4b93db6e0e0deac4dd", null ]
];