var struct_f_u_l_l___s_t_a_t =
[
    [ "closing", "struct_f_u_l_l___s_t_a_t.html#a009fe61aa7b9d66614c1b33a04e01c8f", null ],
    [ "ingredients", "struct_f_u_l_l___s_t_a_t.html#a1bd5b07feb75ca29207f97cc43bea319", null ],
    [ "nCigarettes", "struct_f_u_l_l___s_t_a_t.html#acd01682b81616117748789adc088a4ba", null ],
    [ "nIngredients", "struct_f_u_l_l___s_t_a_t.html#a14b156f34aa6cfd3a6acd37a3b52f5f6", null ],
    [ "nOrders", "struct_f_u_l_l___s_t_a_t.html#a4a53f6fae728f12d421758e6c25756ec", null ],
    [ "nSmokers", "struct_f_u_l_l___s_t_a_t.html#a910f871dabc1fc05ad1b884ba88ca98b", null ],
    [ "reserved", "struct_f_u_l_l___s_t_a_t.html#aefd287d016de3e174fb736b1e94265b2", null ],
    [ "st", "struct_f_u_l_l___s_t_a_t.html#a3ee8c330bbdd743dbb6a612a7c5947f3", null ]
];