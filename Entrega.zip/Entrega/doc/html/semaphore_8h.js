var semaphore_8h =
[
    [ "semConnect", "semaphore_8h.html#a19400f1c69df7ca4198e4d8fa4464188", null ],
    [ "semCreate", "semaphore_8h.html#ab4e4aacaeba5c2c279419ea189d4f46f", null ],
    [ "semDestroy", "semaphore_8h.html#a3b0ff06f25a8e87f1eb734d93ee6468d", null ],
    [ "semDown", "semaphore_8h.html#a54f1aad77d8d2dc932959241de31512b", null ],
    [ "semSignal", "semaphore_8h.html#a47f9e95208f9e756dd4e7b32bcf59cb0", null ],
    [ "semUp", "semaphore_8h.html#ae10d6a38ce2578ac134f5a11ac650954", null ]
];