var logging_8c =
[
    [ "closeLog", "logging_8c.html#abea4c2c8ef3fda57fc2b68d1a9b6e905", null ],
    [ "createLog", "logging_8c.html#a14b9da580ff38a7129ac1f892136164c", null ],
    [ "openLog", "logging_8c.html#a78a5967979eebd64c00b0bddbc12f43d", null ],
    [ "printHeader", "logging_8c.html#ae169f23f397bba25e27d88603605b2b9", null ],
    [ "saveState", "logging_8c.html#a01ad6d5d28960f4b93db6e0e0deac4dd", null ]
];