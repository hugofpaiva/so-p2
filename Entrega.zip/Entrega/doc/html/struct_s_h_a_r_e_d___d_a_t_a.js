var struct_s_h_a_r_e_d___d_a_t_a =
[
    [ "fSt", "struct_s_h_a_r_e_d___d_a_t_a.html#a8c4d1866f41222e1610f6c93b83cfb6b", null ],
    [ "ingredient", "struct_s_h_a_r_e_d___d_a_t_a.html#ad0c463ddc2214e3d20376199aff565b7", null ],
    [ "mutex", "struct_s_h_a_r_e_d___d_a_t_a.html#a0d2548b0a88e106eb9e28289daf576bd", null ],
    [ "wait2Ings", "struct_s_h_a_r_e_d___d_a_t_a.html#a6de9207fcd11e79e7c7888af5b803fb1", null ],
    [ "waitCigarette", "struct_s_h_a_r_e_d___d_a_t_a.html#ab63ec398f4913764799aa5ceeea82422", null ]
];