var shared_memory_8c =
[
    [ "MASK", "shared_memory_8c.html#ae7520c5477c11965aabeedc033c9862b", null ],
    [ "shmemAttach", "shared_memory_8c.html#a23b87532e380b0e07dc275694967f2d9", null ],
    [ "shmemConnect", "shared_memory_8c.html#a9542d28f32b31b22919f8251a12dfc45", null ],
    [ "shmemCreate", "shared_memory_8c.html#a678ef12c3e2b79fd4a9e2ca2d24fdca5", null ],
    [ "shmemDestroy", "shared_memory_8c.html#ad2b8179d03f6f085da9f96f8fad9feaf", null ],
    [ "shmemDettach", "shared_memory_8c.html#a6e0a11f289c7c2f9b9bd29142e16599d", null ]
];