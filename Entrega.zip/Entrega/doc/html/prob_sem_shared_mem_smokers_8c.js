var prob_sem_shared_mem_smokers_8c =
[
    [ "AGENT", "prob_sem_shared_mem_smokers_8c.html#aca911f15c3c4be4021ce2297239a2c06", null ],
    [ "SMOKER", "prob_sem_shared_mem_smokers_8c.html#a7996543b4498adf6cdf3c0cc7eb6bb11", null ],
    [ "WATCHER", "prob_sem_shared_mem_smokers_8c.html#a29e1b9e32da570f0aeee2a90794b3ec9", null ],
    [ "main", "prob_sem_shared_mem_smokers_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];