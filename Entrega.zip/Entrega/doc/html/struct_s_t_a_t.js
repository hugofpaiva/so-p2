var struct_s_t_a_t =
[
    [ "agentStat", "struct_s_t_a_t.html#af899b9d7f810a22fe8b91cecd2c46713", null ],
    [ "smokerStat", "struct_s_t_a_t.html#acde7256e8bfad767dd177d5eacc12783", null ],
    [ "watcherStat", "struct_s_t_a_t.html#a772277dbe20a066aa1b10525a5af03a3", null ]
];